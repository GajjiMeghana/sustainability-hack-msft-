# Sustainability-hack
To develop a website where farmers can directly sell their products and consumers can buy through the website without involving middlemen.
